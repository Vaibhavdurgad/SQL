from loguru import logger
import logging
import math
import configparser

# logging.basicConfig(format='%(asctime)s,%(msecs)03d %(levelname).8s [%(filename)s:%(lineno)d] %(message)s',
#                     datefmt='%Y-%m-%d:%H:%M:%S',level =logging.DEBUG)
# length =100
# breadth =200
# total =length *breadth
# rounded=math.ceil(15/7)

# print(rounded) 


#if else 

# logging.info(f'cost of bricks per unit is {total} sq ft')

# length_of_land = int(input('Enter the length of your land: '))
# if (length_of_land <100):
#     logger.info(f'Your length is not sufficient to build 4 BHK')
#     logger.info(f'Second line')
# elif length_of_land>500:
#     logger.info(f'Your can bulid more than 2 buildings')
# else:
#     logger.info(f'Share more details with us')
#     logger.info(f'Third line')


#List
#labour=['Mahesh','Ramesh','Sumesh']
#for i in range(len(labour)):
#    logger.info(f'labour {i+1} name is {labour[i]}')

#for i in range(5):
#    print((i+1)*' * ')

#for i in range(1,101):
#    if i % 2 ==0:
#        print(i)

# pargraph =""""The sun was just beginning to rise over the horizon, 
# casting a warm golden glow across the quiet town. 
# Birds chirped softly in the distance, and the gentle breeze rustled through the trees. 
# As Emma walked down the path, she felt the crisp morning air on her face and took in the beauty of the world waking up around her. The peacefulness of the moment reminded her of childhood summers spent exploring the woods near her grandparents' house. Everything felt calm, 
# as if the day held infinite possibilities."""

# pargraph_list =pargraph.lower().split(' ')
# count=0
# for letter in pargraph_list:
#     if letter == 'the':
#         count= count + 1
#     else:
#         continue

# logger.info(f'Total count for the articel is {count}')


# labour=['Mahesh','Ramesh','Sumesh']
# name= 0
# while (name<len(labour)):
#     print(labour[name])
#     name=name+1


# def final(*args,discount=0.1):
#     try:
#         result =0
#         for amount in args:
#             result += amount
#         amount_after_discount = result-(result*discount)
#         return amount_after_discount
#     except TypeError:
#         logger.info('Please provide the amount in interger')
#         raise Exception('Value provided is not an interger')
#     except Exception as e:
#         logger.info('Can not Process the cart amount')
#         raise e
# try:
#     final_amount =final(100,500,120,300,'500',discount=0.5)
#     logger.info(final_amount)
# except Exception as e:
#     logger.info('Entry Database ')


config = configparser.ConfigParser()
config.read(r"c:\Users\vaibhav.durgad\Practice\config_file.ini")
brick_cost=config["raw_materials"]["brick_cost"]
logger.info(f"{brick_cost}")



