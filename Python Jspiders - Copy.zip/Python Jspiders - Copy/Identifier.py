# identifier is a name with which we can identify variables,functions,classes
# Rules : we should not use keyword as identifier
# True = 12  WRONG WAY
value = 12

# first charactor of identifier should not be numeric value
# 1value = 12        wrong
value1 = 12

# otherthan underscore we should not use any spl charactor
# variable@1 = 100
variable_1 = 100

# we can use alpha,no,("_") to create an identifier
# std rules
# variables = use only lower case
# functions = first word should be in lowercase and other words should be in title case
# firstfunction()      wrong
# firstFunction()      right
# class = TitleCase
# BankingClass










