name = "sonali"
place = "pune"


print(f"my name is {name}")
print(f"{name} is currently living in {place}")
