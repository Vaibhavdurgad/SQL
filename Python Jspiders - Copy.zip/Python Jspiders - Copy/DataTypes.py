# DataTypes = datatypes are used for defining the type of data that we are going to store in a variable

# 1)single valued datatypes:
# i) Number datatypes: integer, float , complex
# ii) Boolean datatypes : True, False

# int ---- number without floating point
a = 19
print(type(a))
b = -100
print(type(b))

# float-------number with floating point

c = 2.5
print(type(c))
d = -10.89
print(type(d))

# complex --- combination of real and imaginary
comp = 3 + 5j
print(type(comp))
print(comp.real)
print(comp.imag)

comp_var = 9 + 8j
# boolean----- bool
r = True
print(type(r))
c = False
print(type(c))
value = 10
